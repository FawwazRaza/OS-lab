#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char *argv[]) {
    char mess[200];
    int fd;
mkfifo("npipe",0777);

    fd = open("npipe", O_RDONLY);
    if (fd == -1) {
        perror("Error ");
        return 1;
    }

    if (read(fd, mess, sizeof(mess)) == -1) {
        perror("Error");
        close(fd);
        return 1;
    }

    close(fd);
    printf(": %s\n", mess);

   

    return 0;
}

