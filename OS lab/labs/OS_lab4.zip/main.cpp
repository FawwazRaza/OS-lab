#include <bits/stdc++.h>
#include"header.h"
using namespace std;
void sort1(int array[],bool order,int size)
{
 if(order==true)
 {
 cout<<"ASC sorted array : \n";
  sort(array,array+size);
  for (int i=0;i<size;i++)
  {
      cout<<array[i]<<" | "; 
  }
 }
 else if(order==false)
 {
  cout<<"DESC sorted array : \n";
  sort(array,array+size);
  for (int i=size-1;i>=0;i--)
  {
      cout<<array[i]<<" | "; 
  }
 }
}

void findHighest(int array[],int nth)
{
int size=10;
int arr[10]={0};
 sort(array,array+size);
  for (int i=size-1;i>=0;i--)
  {
  arr[i]=array[i];
  }
    cout << endl << nth<<"  Largest element = " << arr[nth-1];

}
void print(int array[],int size)
{
int i=0;
 while(i<size)
 {
 cout<<array[i]<<" | ";
 i++;
 }
 
}

int main()
{
    int arr[10]={11,15,13,12,16,14,18,19,20,17};
    int s=10;
    cout<<endl<<"Print array : "<<endl;
    print(arr,s);
    cout<<endl;
    cout<<endl;
    sort1(arr,false,s);
    cout<<endl;
    sort1(arr,true,s);
    cout<<endl;
    findHighest(arr,2);
    return 0;
}

