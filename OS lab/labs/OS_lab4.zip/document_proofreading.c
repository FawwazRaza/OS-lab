#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <math.h>

int main() {
    int pipe1[2], pipe2[2];
    int num;
    pid_t pid;

    if (pipe(pipe1) == -1 || pipe(pipe2) == -1) {

        //exit(EXIT_FAILURE);
    }

    pid = fork();

    if (pid < 0) {

        //exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        close(pipe1[1]);

        read(pipe1[0], &num, sizeof(num));

        close(pipe1[0]);

        double result = (num*num);

        close(pipe2[0]);

        write(pipe2[1], &result, sizeof(result));

        close(pipe2[1]);

       // exit(EXIT_SUCCESS);
    } else {
        close(pipe1[0]);

        printf("Enter an integer: ");
        scanf("%d",num);

        write(pipe1[1], &num, sizeof(num));

        close(pipe1[1]);

        wait(NULL);

        close(pipe2[1]);

        double result;
        read(pipe2[0], &result, sizeof(result));

        close(pipe2[0]);

        printf( "Square root of %d\n" , result );
    }

    return 0;
}
