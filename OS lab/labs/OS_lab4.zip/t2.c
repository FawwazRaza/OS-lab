#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <ctype.h>
void remove_special_characters(char *text) {
    int i, j = 0;
    for (i = 0; text[i] != '\0'; i++) {
        if (isalpha(text[i]) || isspace(text[i])) {
            text[j++] = text[i];
        }
    }
    text[j] = '\0';
}

int main() {
    int fd[2];
    pid_t pid;
    char document[100];

    if (pipe(fd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid = fork();

    if (pid < 0) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        close(fd[1]);
        read(fd[0], document, sizeof(document));

        remove_special_characters(document);

        printf("Student: Cleaned version of the document:\n%s\n", document);

        close(fd[0]);  
        exit(EXIT_SUCCESS);
    } else {
        close(fd[0]);  
        printf("Teacher: Enter the document for proofreading:\n");
        fgets(document, sizeof(document), stdin);
        write(fd[1], document, strlen(document) + 1);

        close(fd[1]);  
        wait(NULL);    
    }

    return 0;
}
