
void sort1(int array[],bool order,int size);
void findHighest(int array[],int nth);
void print(int array[],int size);
